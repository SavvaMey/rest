create view londonstaff(id, name) as
SELECT company.id,
       company.name
FROM company
WHERE company.name::text = 'volvo'::text;

alter table londonstaff
    owner to postgres;

